package com.example.helpdeskapi.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name="tickets")
@Setter
@Getter
@NoArgsConstructor
public class TicketEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long request;
    private String issue;
    private String description;
    private String status;
    @CreationTimestamp
    private LocalDateTime createdat;
    @CreationTimestamp
    private LocalDateTime updatedat;
}
